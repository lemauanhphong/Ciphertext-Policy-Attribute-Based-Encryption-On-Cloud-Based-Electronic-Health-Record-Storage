with open("ed25519pubkey.pem", "rb") as f:
    JWT_PUBKEY = f.read()